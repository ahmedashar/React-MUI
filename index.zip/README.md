# React + Vite + MUI

1. Typography
2. Button, Icons (npm i @mui/icons-material), IconButton, Stack, ButtonGroup, ToggleButtonGroup, ToggleButton
3. TextField, Input Andornment
4. FormControl, FormLabel, RadioGroup, FormControlLabel, Radio
5. Checkbox, Switch
6. Rating